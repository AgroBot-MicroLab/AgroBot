<script setup>
import Map from './components/Map.vue'
</script>

<template>
    <Map />
    <h1> Test </h1>
</template>

<style scoped>
</style>
