DROP TABLE IF EXISTS test_table;

