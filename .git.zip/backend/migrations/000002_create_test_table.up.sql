CREATE TABLE test_table (
    id SERIAL PRIMARY KEY,
    test VARCHAR NOT NULL
);

